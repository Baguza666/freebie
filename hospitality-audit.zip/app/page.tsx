import HospitalityLeadAudit from "@/components/hospitality-lead-audit"

export default function Page() {
  return <HospitalityLeadAudit />
}
